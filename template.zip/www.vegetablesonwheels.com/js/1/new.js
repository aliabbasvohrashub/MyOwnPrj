function deleteCookie(){
		 
		
		var cvalue = getCookie('dc');
		var cqty = getCookie('cqty');
		var crate = getCookie('crate');
		var itemC = getCookie('itemctr');
		
				
		if (cvalue!=null && cvalue!=''){
			document.cookie = 'dc='+ '';
			
			document.getElementById('fbox').innerHTML = '';
			document.getElementById('gtotal').innerHTML = 0;
		
			
		}
		
		if (cqty!=null && cqty!=''){
			document.cookie = 'cqty='+ '';
			document.cookie = 'itemctr='+ '';
		}
		if (crate!=null && crate!=''){
			document.cookie = 'crate='+ '';
		}
		
}


function logout(){
		
		deleteCookie();
		document.cookie= 'username='+'';
		window.location = 'http://www.vegetablesonwheels.com/Logout.php'; 
}

function deleteitem(name){

var names = 'fname'+name;
var node = document.getElementById(names);
node.parentNode.removeChild(node);

names = 'fqty'+name;
node = document.getElementById(names);
node.parentNode.removeChild(node);

names = 'frate'+name;
node = document.getElementById(names);
node.parentNode.removeChild(node);

names = 'fprice'+name;
node = document.getElementById(names);
var price = node.innerHTML;
node.parentNode.removeChild(node);

names = 'fimg'+name;
node = document.getElementById(names);
node.parentNode.removeChild(node);

var priceId = 'fprice'+name;



	var items = getCookie('dc');
	var qty = getCookie('cqty');
	var rate = getCookie('crate');
	
	var itemArray = items.split(', ');
	var itemQty = qty.split(', ');
	var itemRate = rate.split(', ');
	
	var newItem = '';
	var newQty = '';
	var newRate = '';
		
	if(itemArray.length >0){
	
		for(var i=0; i<itemArray.length; i++){
			
			if (itemArray[i] == name){
				newItem = newItem + '';
				newQty = newQty + '';
				newRate = newRate + '';

			}
			else if(itemArray.length == 1){
					newItem = itemArray[i];
					newQty = itemQty[i];
					newRate = itemRate[i];
					
			}
			else{
				if (i == 0){
					newItem = newItem + itemArray[i] + ', ';
					newQty = newQty + itemQty[i] + ', ';
					newRate = newRate + itemRate[i] + ', ';
					
				}
				else if(i ==(itemArray.length)-1){
					
					newItem = newItem + itemArray[i];
					newQty = newQty + itemQty[i];
					newRate = newRate + itemRate[i];
				}
				else{
					newItem = newItem + itemArray[i] + ', ';
					newQty = newQty + itemQty[i] + ', ';
					newRate = newRate + itemRate[i] + ', ';
					
				}
			}
			
		}
			
	}
	
if (newItem.substring(newItem.length-2, newItem.length-1)== ','){
	
	
	newItem = newItem.substring(0, newItem.length-2);
	newRate = newRate.substring(0, newRate.length-2);
	newQty = newQty.substring(0, newQty.length-2);
}

	
document.cookie = 'dc='+ '';
document.cookie = 'cqty='+ '';
document.cookie = 'crate='+ '';


document.cookie = 'dc='+ newItem;
document.cookie = 'cqty='+ newQty;
document.cookie = 'crate='+ newRate;

var remItem = newItem.split(', ');
var remItem2 = parseInt(remItem.length);
document.cookie = 'itemctr='+'';
document.cookie = 'itemctr='+remItem2;
document.getElementById('xx').innerHTML = '<span>' +remItem2 + ' Item(s)</span>';	

var grandtotal = parseFloat(document.getElementById('gtotal').innerHTML);
grandtotal = grandtotal - price;
document.getElementById('gtotal').innerHTML = grandtotal;

}

function addtocart(name, rate){
	
	var cvalue = getCookie('dc');
	var c_qty = getCookie('cqty');
	var c_rate = getCookie('crate');
	var ctr=0;
	var ctr2 =0;

	if (cvalue!=null && cvalue!=''){
	if (cvalue.indexOf(name)!=-1){
	

		var selqty = document.getElementById(name).text;
		var selqtyKg = document.getElementById(name).value;
		var price = (parseFloat(rate) * parseFloat(selqtyKg));
		var finalTotal = parseFloat(document.getElementById('gtotal').innerHTML);
				
		var names = 'fqty'+name;
		var node1 = document.getElementById(names).innerHTML;
		var totalQty = parseFloat(node1) + parseFloat(selqtyKg);
	
		var totalPrice = (parseFloat(rate) * parseFloat(totalQty));
	
		
		document.getElementById(names).innerHTML = totalQty;
		names = 'fprice'+name;
		var init = parseFloat(document.getElementById(names).innerHTML);
		
		document.getElementById(names).innerHTML = totalPrice;
		finalTotal = finalTotal + totalPrice - init;
		document.getElementById('gtotal').innerHTML = finalTotal;
		
				var itemArray = cvalue.split(', ');
				var itemQty = c_qty.split(', ');
				var itemRate = c_rate.split(', ');
				
				var newItem = '';
				var newQty = '';
				var newRate = '';
					
				if(itemArray.length >0){
				
					for(var i=0; i<itemArray.length; i++){
					
						if(i==0){
							if (itemArray[i] == name){
									newQty = totalQty+', ';
								
							}else{newQty = itemQty[i]+', ';}
							
						}else{
							if (itemArray[i] == name){
									newQty = newQty + parseFloat(totalQty) + ', ' ;
															
							}else{
								newQty = newQty + itemQty[i]+', ' ;
								
		
								
							}
		
						}
						
					}
			
				}
			if (newQty.substring(newQty.length-2, newQty.length-1)== ','){
				
		
				newQty = newQty.substring(0, newQty.length-2);
			}
			document.cookie = 'cqty='+ '';
			document.cookie = 'cqty='+ newQty;
			var remItem = newQty.split(', ');
			var remItem2 = parseInt(remItem.length );
			document.cookie = 'itemctr='+'';
			document.cookie = 'itemctr='+remItem2;
			document.getElementById('xx').innerHTML = '<span>' +remItem2 + ' Item(s)</span>';
					
		return;

			
	}}
 
 
	
	var selqty = document.getElementById(name).text;
	var selqtyKg = document.getElementById(name).value;
	var price = (parseFloat(rate) * parseFloat(selqtyKg));
	var divtag = document.getElementById('fbox');
	var newdivtag = document.createElement('div');
	var newdivtag2 = document.createElement('div');
	var newdivtag3 = document.createElement('div');
	var newdivtag4 = document.createElement('div');
	var newdivtag5 = document.createElement('div');
	
	var grandtotal = parseFloat(document.getElementById('gtotal').innerHTML);
	grandtotal = grandtotal + price;
	
	
	newdivtag.className = 'fbox_n';
	newdivtag.id = 'fname'+name;
	newdivtag.innerHTML = name;
	document.getElementById('fbox').appendChild(newdivtag);
	
	newdivtag2.className = 'fbox_p';
	newdivtag2.id = 'fqty'+name;
	newdivtag2.innerHTML = selqtyKg;
	document.getElementById('fbox').appendChild(newdivtag2);
	
	
	newdivtag3.className = 'fbox_p1';
	newdivtag3.id = 'frate'+name;
	newdivtag3.innerHTML = rate;
	document.getElementById('fbox').appendChild(newdivtag3);
	
	
	newdivtag4.className = 'fbox_pa';
	newdivtag4.id = 'fprice'+name;
	newdivtag4.innerHTML = price;
	document.getElementById('fbox').appendChild(newdivtag4);
	
	newdivtag5.className = 'fbox_cls';
	newdivtag5.id = 'fimg'+name;
	var str = "<span><a href='javascript:deleteitem(\""+name+"\");'><img src='images/floting_close_btnsmll.png' alt='' width='11' height='11' border='0' /></span></a>";
	newdivtag5.innerHTML = str;
	document.getElementById('fbox').appendChild(newdivtag5);
	
	document.getElementById('gtotal').innerHTML = grandtotal;
	
	
	if(cvalue!=null && cvalue!=''){
		ctr = cvalue.split(', ');
		ctr2 = parseInt(ctr.length + 1);
	}else{
		ctr2 = 0;
	}
	
		
	if (cvalue!=null && cvalue!=''){
		document.cookie = 'dc='+cvalue +', '+name;
		document.getElementById('xx').innerHTML = '<span>' +ctr2 + ' Item(s)</span>';
					
	}
	else{
		document.cookie='dc=' + name; 
		document.getElementById('xx').innerHTML = '<span>' +ctr2 + ' Item(s)</span>';
	}
		
	if (c_qty!=null && c_qty!=''){
		document.cookie = 'cqty='+c_qty+', '+selqtyKg;
	}else{
		document.cookie='cqty=' +selqtyKg; 
	
	}
	
	if (c_rate!=null && c_rate!=''){
		document.cookie = 'crate='+c_rate+', '+ rate;
		
	}else{
		document.cookie='crate=' + rate;
		
	}
	
		
}
    
function democookie(){
	
		var items = getCookie('dc');
		var user = getCookie('username');
		if (items!=null && items!=''){

		}
		
		var qty = getCookie('cqty');
		if (qty!=null && qty!=''){

		}
		
		var myrate = getCookie('crate');
		if (myrate!=null && myrate!=''){
			
		}else{}
		
		var chkPage = document.getElementById('gtotal');//check if page has gtotal or not.
		if(chkPage==null){
			if(user=='' || user==null){
				alert('Please login first from Login Here button at top menu.');
				
			}else{
			window.location = 'http://www.vegetablesonwheels.com/checkout.php'; }
		
		}
		
		else{
			var total = parseFloat(document.getElementById('gtotal').innerHTML);
			var myslot = document.getElementById('selectslot').value;
			
			document.cookie='slot=' + myslot; 
			
			
			if(total  < 100){
				alert ('Please choose order more than Rs. 100. Your order is Rs. ' +total);
				return;
			}else{
				if(user=='' || user==null){
					alert('Please login first from Login Here button at top menu.');
					
				}else{
				window.location = 'http://www.vegetablesonwheels.com/checkout.php'; }
			
			}
		}
}
	 
function getCookie(name) {
		var start = document.cookie.indexOf( name + '=' );
		var len = start + name.length + 1;
   
      if ( ( !start ) && ( name != document.cookie.substring( 0, name.length ) ) ) {
   
      return null;
   
      }
   
      if ( start == -1 ) return null;
   
      var end = document.cookie.indexOf( ';', len );
   
      if ( end == -1 ) end = document.cookie.length;
  
      return unescape( document.cookie.substring( len, end ) );
}	  


	function loadcontent(){
  
	var items = getCookie('dc');
	var qty = getCookie('cqty');
	var rate = getCookie('crate');
	
	var itemArray = items.split(', ');
	var itemQty = qty.split(', ');
	var itemRate = rate.split(', ');
	var gtotal=0;
	var uname = getCookie('username');
	
	if(itemArray.length >0){
	
	if(items!='' && items!=null){	
		var divtag = document.getElementById('fbox');
		
		if (divtag==null){//check if shopping cart is available or not . . .
			document.getElementById('xx').innerHTML = '<span>' +itemArray.length + ' Item(s)</span>'; 
		
		}else{
			for(var i=0; i<itemArray.length; i++){
				
				var newdivtag = document.createElement('div');
				var newdivtag2 = document.createElement('div');
				var newdivtag3 = document.createElement('div');
				var newdivtag4 = document.createElement('div');
				var newdivtag5 = document.createElement('div');
				
				
				newdivtag.className = 'fbox_n';
				newdivtag2.className = 'fbox_p';
				newdivtag3.className = 'fbox_p1';
				newdivtag4.className = 'fbox_pa';
				newdivtag5.className = 'fbox_cls';
				
				newdivtag.id = 'fname'+itemArray[i];
				newdivtag2.id = 'fqty'+itemArray[i];
				newdivtag3.id = 'frate'+itemArray[i];
				newdivtag4.id = 'fprice'+itemArray[i];
				newdivtag5.id = 'fimg'+itemArray[i];
				
				gtotal = gtotal + (parseFloat(itemRate[i]) * parseFloat(itemQty[i]));
							
				newdivtag.innerHTML = itemArray[i]; 
				newdivtag2.innerHTML = itemQty[i];
				newdivtag3.innerHTML = itemRate[i];
				newdivtag4.innerHTML = (parseFloat(itemRate[i]) * parseFloat(itemQty[i]));		
				var str = "<span><a href='javascript:deleteitem(\""+itemArray[i]+"\");'><img src='images/floting_close_btnsmll.png' alt='' width='11' height='11'  border='0'/></span></a>";
				newdivtag5.innerHTML = str;
							
				document.getElementById('gtotal').innerHTML = gtotal;
				
				document.getElementById('fbox').appendChild(newdivtag);
				document.getElementById('fbox').appendChild(newdivtag2);
				document.getElementById('fbox').appendChild(newdivtag3);
				document.getElementById('fbox').appendChild(newdivtag4);
				document.getElementById('fbox').appendChild(newdivtag5);
			}
			document.getElementById('xx').innerHTML = '<span>' +itemArray.length + ' Item(s)</span>'; 
			
		
		
		
		
		}
	
		
		
	}}
	if(items!='' && items!=null){
		if(itemArray.length==0){
			document.getElementById('xx').innerHTML = 'Empty Cart';
			
		}
	
	}else{
		
		document.getElementById('gtotal').innerHTML = 0;
		document.getElementById('xx').innerHTML = 'Empty Cart';
	}
	
	if(uname!='' && uname!=null){
		
			document.getElementById('user').innerHTML = '<strong>Welcome,<br /> ' + uname + '</strong>';
			
		
	
	}
	
	priceList('english');
}

function downloadlist(){
		var url='http://www.vegetablesonwheels.com/pricelist.php'; 
		window.open(url,'Download');
}

function priceList(lang)
{
	if(lang == 'gujarati')
	{
				document.getElementById('listPriceg').style.display='block';
				document.getElementById('listPrice').style.display='none';
				document.getElementById('vegListg').style.display='block';
				document.getElementById('vegList').style.display='none';
				document.getElementById('gujarati-button').src='images/gujarati-btn-ovr.jpg';
				document.getElementById('english-button').src='images/english-btn.jpg';
	}
	else
	{
				document.getElementById('listPriceg').style.display='none';
				document.getElementById('listPrice').style.display='block';
				document.getElementById('vegListg').style.display='none';
				document.getElementById('vegList').style.display='block';
				document.getElementById('gujarati-button').src='images/gujarati-btn.jpg';
				document.getElementById('english-button').src='images/english-btn-ovr.jpg';
	}
}