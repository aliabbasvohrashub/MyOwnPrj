function validation()
{
	//alert("kaushal;	");
	regname= document.getElementById('regname').value;
	username = document.getElementById('username').value;
	password = document.getElementById('password2').value;
	regaddress = document.getElementById('regaddress').value;
	email = document.getElementById('email').value;
	contact =document.getElementById('contact').value;
	error = "";
	if(regname == '')
	{	
		error += "Please Enter your name. \n";
	}
	if(username == '')
	{
		error += "Please Enter user name. \n";
	}
	if(password == '')
	{
		error += "Please Enter Password Properly. \n";
	}
	if(regaddress == '')
	{
	error += "Please Enter Address. \n";
	}
	if(email == '')
	{	
		error += "Please Enter Email Address. \n";
	}
	if(email != '')
	{	
  		var reg = /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;
		 if(reg.test(email) == false) 
		 {
      				error +="Invalid Email Address. \n";
  			}
	}
	if(contact == '')
	{
		error +="Please Enter contact number";
	}
	if(error != "")
	{
		alert(error);
	}
	else
	{
		document.getElementById('josForm').submit();
	}
}
function chkImg()
{
}
