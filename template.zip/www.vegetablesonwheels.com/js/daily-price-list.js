function priceList(lang)
{
	if(lang == 'gujarati')
	{
				document.getElementById('listPriceg').style.display='block';
				document.getElementById('listPrice').style.display='none';
				document.getElementById('vegListg').style.display='block';
				document.getElementById('vegList').style.display='none';
				document.getElementById('gujarati-button').src='images/gujarati-btn-ovr.jpg';
				document.getElementById('english-button').src='images/english-btn.jpg';
	}
	else
	{
				document.getElementById('listPriceg').style.display='none';
				document.getElementById('listPrice').style.display='block';
				document.getElementById('vegListg').style.display='none';
				document.getElementById('vegList').style.display='block';
				document.getElementById('gujarati-button').src='images/gujarati-btn.jpg';
				document.getElementById('english-button').src='images/english-btn-ovr.jpg';
	}
}
